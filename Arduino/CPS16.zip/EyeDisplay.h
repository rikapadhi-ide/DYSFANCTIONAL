#pragma once
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_GC9A01A.h>
#include "EyeArt2.h"

namespace EyeDisplay {
  // Display: SCK=12, MOSI=11, CS=10, DC=9, RST=8
  Adafruit_GC9A01A screen(&SPI, 9, 10, 8);
  uint32_t lastFrame = 0;
  int state = 0;
}

void eyeSet(int input) {
  if (input < 1 || input > 4 || input == EyeDisplay::state) return;
  const int modes[] = {0, 4, 2, 3, 1};
  EyeDisplay::state = input;
  mode = modes[input];
  modeStart = millis() / 1000.0f;
}

void eyeBegin() {
  SPI.begin(12, -1, 11, 10);
  EyeDisplay::screen.begin(40000000);
  EyeDisplay::screen.setRotation(0);
  EyeDisplay::screen.fillScreen(BG);
  EyeDisplay::lastFrame = millis();
  eyeSet(4);
}

void eyeUpdate() {
  uint32_t now = millis();
  uint32_t elapsed = now - EyeDisplay::lastFrame;
  if (elapsed < 33) return;
  EyeDisplay::lastFrame = now;
  renderEye(now / 1000.0f, elapsed / 1000.0f);
  EyeDisplay::screen.startWrite();
  EyeDisplay::screen.setAddrWindow(0, 40, 240, 156);
  EyeDisplay::screen.writePixels(pixels + 40 * 240, 240 * 156);
  EyeDisplay::screen.endWrite();
}
