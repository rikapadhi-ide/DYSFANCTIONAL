#pragma once
#include <math.h>
#include <stdint.h>
// RGB565 approximation of reference: coral #FF6247, blue #087FE8,
// ink #2C3443, warm white #FFFDF7. No bitmaps or SD card required.
const uint16_t BG=0xFB08, BLUE=0x0BFD, INK=0x29A8, WHITE=0xFFDE;
static uint16_t pixels[240*240]; // 115,200 bytes. ESP32-S3 only, not Nano Every.
float minv(float a,float b){return a<b?a:b;}
float maxv(float a,float b){return a>b?a:b;}
float absf(float x){return x<0?-x:x;}
void clearFrame(uint16_t c){for(int i=0;i<57600;i++) pixels[i]=c;}
void vstrip(int x,float a,float b,uint16_t c){
 if(x<0||x>=240||a>b)return;
 int first=(int)ceilf(maxv(0,a)), last=(int)floorf(minv(239,b));
 for(int y=first;y<=last;y++)pixels[y*240+x]=c;
}
void disk(float cx,float cy,float r,uint16_t c){
 for(int x=(int)ceilf(cx-r);x<=(int)floorf(cx+r);x++){
 float d=x-cx, h=sqrtf(maxv(0,r*r-d*d));vstrip(x,cy-h,cy+h,c);
 }
}
// Tune these values first. Both preview and Arduino use these defaults.
// ROUGHNESS: increase for wobblier hand-drawn lines; 0 = clean geometry.
const float ROUGHNESS=1.15f;
// MOTION_SPEED: 1 = normal, 1.3 = 30% faster, 0.7 = slower.
const float MOTION_SPEED=1.0f;
// FEAR_SHAKE: amplitude in pixels; increase for more dramatic trembling.
const float FEAR_SHAKE=2.0f;
// Transition/smoothing time in seconds. 0.055 is brisk; 0.12 is softer.
const float TRANSITION_SECONDS=0.055f;
const float PI_F=3.14159265359f;
int mode=3;
float modeStart=0, smoothOpen=0.94f, smoothGX=0, smoothGY=0;
float smoothIris=37, smoothPupil=15, smoothCY=133, smoothBrow=0, smoothTilt=0;
float topEdge[240],bottomEdge[240];

float sat(float x) { return minv(1.0f,maxv(0.0f,x)); }
float ease(float x) { x=sat(x); return x*x*(3.0f-2.0f*x); }
float mixv(float a,float b,float k) { return a+(b-a)*k; }
// Fixed spatial wobble: no random noise per frame, so lines do not flicker.
float wobble(float u,float seed) {
 return ROUGHNESS*(0.52f*sinf(13.0f*u+seed)+0.28f*sinf(29.0f*u+seed*2.0f));
}
float blink(float t,float start,float length) {
 float q=(t-start)/length;
 if(q<0.0f || q>1.0f) return 1.0f;
 return 1.0f-sinf(q*PI_F);
}
void selectMode(int value,float now) {
 if(value<1 || value>4 || value==mode) return;
 mode=value; modeStart=now;
}
void renderEye(float now,float dt) {
 float t=(now-modeStart)*MOTION_SPEED;
 float open=1.0f, gx=0.0f, gy=0.0f, iris=37.0f, pupil=15.0f;
 float cy=133.0f, brow=0.0f, tilt=0.0f, shakeX=0.0f, shakeY=0.0f;
 if(mode==1) {
   // 6 second gag: heavy lids, asleep, startled awake, then drooping again.
   float q=fmodf(t,6.0f);
   if(q<2.8f) open=mixv(0.52f,0.025f,ease(q/2.8f));
   else if(q<4.1f) open=0.025f;
   else if(q<4.28f) open=mixv(0.025f,1.22f,ease((q-4.1f)/0.18f));
   else if(q<4.85f) open=1.22f-0.10f*sinf((q-4.28f)*15.0f);
   else open=mixv(1.12f,0.52f,ease((q-4.85f)/1.15f));
   cy=133.0f+8.0f*(1.0f-sat(open));
   gy=5.0f*(1.0f-sat(open)); gx=3.0f*sinf(t*0.8f);
   brow=-7.0f*(1.0f-sat(open)); tilt=-5.0f;
 } else if(mode==2) {
   open=1.18f; iris=29.0f; pupil=8.0f;
   shakeX=FEAR_SHAKE*(sinf(43.0f*t)+0.35f*sinf(67.0f*t));
   shakeY=FEAR_SHAKE*0.45f*sinf(51.0f*t);
   gx=6.0f*sinf(15.0f*t); gy=-2.0f;
   brow=10.0f; tilt=3.0f*sinf(8.0f*t);
   float q=fmodf(t,3.7f);
   open*=blink(q,3.0f,0.13f)*blink(q,3.22f,0.13f);
 } else if(mode==3) {
   // Reluctant kindness: side-eye, eye-roll, long sigh, then a tiny agreeing nod.
   // Play once, then hold the accepting expression until the action ends.
   float q=minv(t,7.19f);
   open=0.62f; gx=22.0f; gy=0.0f; brow=-3.0f; tilt=-9.0f;
   if(q<1.2f) {
     gx=22.0f*ease(q/0.35f);
   } else if(q<2.3f) {
     float a=ease((q-1.2f)/1.1f);
     gx=22.0f*cosf(a*PI_F);
     gy=-22.0f*sinf(a*PI_F);
     open=0.62f+0.23f*sinf(a*PI_F);
     brow=-3.0f+6.0f*sinf(a*PI_F); tilt=-9.0f+5.0f*a;
   } else if(q<3.0f) {
     float a=ease((q-2.3f)/0.7f);
     gx=mixv(-22.0f,0.0f,a); open=mixv(0.62f,0.025f,a);
     cy=133.0f+6.0f*a; brow=-3.0f-5.0f*a; tilt=-4.0f;
   } else if(q<3.9f) {
     // Closed-eye exhale: a slow downward settle, not a sleepy head bob.
     float a=ease((q-3.0f)/0.9f);
     gx=0.0f; open=0.025f; cy=139.0f+3.0f*a;
     brow=-8.0f-2.0f*a; tilt=-4.0f;
   } else if(q<4.6f) {
     float a=ease((q-3.9f)/0.7f);
     gx=0.0f; open=mixv(0.025f,0.68f,a);
     cy=mixv(142.0f,133.0f,a); brow=mixv(-10.0f,1.0f,a);
     tilt=mixv(-4.0f,7.0f,a);
   } else if(q<5.3f) {
     float a=(q-4.6f)/0.7f;
     gx=0.0f; gy=3.0f*sinf(a*PI_F);
     open=0.68f-0.12f*sinf(a*PI_F);
     cy=133.0f+5.0f*sinf(a*PI_F);
     brow=1.0f; tilt=7.0f;
   } else if(q<7.2f) {
     gx=0.0f; open=0.68f*blink(q,6.4f,0.28f);
     brow=1.0f; tilt=7.0f;
   } else {
     float a=ease((q-7.2f)/0.8f);
     gx=22.0f*a; open=mixv(0.68f,0.62f,a);
     brow=mixv(1.0f,-3.0f,a); tilt=mixv(7.0f,-9.0f,a);
   }
 } else {
   // Mode 4 retains the original normal look-around.
   float offset=mode==4 ? 1.4f : 0.0f;
   float q=fmodf(t+offset,7.0f);
   if(q<1.4f) gx=0.0f;
   else if(q<1.65f) gx=22.0f*ease((q-1.4f)/0.25f);
   else if(q<2.65f) gx=22.0f;
   else if(q<2.95f) gx=mixv(22.0f,-20.0f,ease((q-2.65f)/0.3f));
   else if(q<4.0f) gx=-20.0f;
   else if(q<4.3f) gx=-20.0f*(1.0f-ease((q-4.0f)/0.3f));
   gy=1.8f*sinf(t*1.2f);
   open=(0.94f+0.025f*sinf(t*1.8f))*blink(q,4.7f,0.24f)*blink(q,5.12f,0.18f);
   brow=2.0f*sinf(t*1.2f); tilt=gx*0.14f;
 }
 // Smaller TRANSITION_SECONDS = snappier transitions; larger = softer/slower.
 float k=1.0f-expf(-minv(dt,0.1f)/TRANSITION_SECONDS);
 smoothOpen=mixv(smoothOpen,open,k); smoothGX=mixv(smoothGX,gx,k);
 smoothGY=mixv(smoothGY,gy,k); smoothIris=mixv(smoothIris,iris,k);
 smoothPupil=mixv(smoothPupil,pupil,k); smoothCY=mixv(smoothCY,cy,k);
 smoothBrow=mixv(smoothBrow,brow,k); smoothTilt=mixv(smoothTilt,tilt,k);
 clearFrame(BG);
 float cx=120.0f+shakeX, ey=smoothCY+shakeY;
 float ix=cx+smoothGX, iy=ey+smoothGY;
 // Draw vertical strips; iris is clipped by upper/lower lids, never floats outside.
 for(int x=17;x<=223;x++) {
   float u=(x-cx)/99.0f;
   if(absf(u)>1.0f) continue;
   float arch=maxv(0.0f,1.0f-u*u);
   float top=ey-43.0f*smoothOpen*arch+wobble(u,1.0f)*arch;
   float bottom=ey+37.0f*smoothOpen*arch+wobble(u,3.0f)*arch;
   topEdge[x]=top; bottomEdge[x]=bottom;
   vstrip(x,top,bottom,WHITE);
   float dx=x-ix;
   float rr=smoothIris+wobble(u,5.0f)*0.4f;
   if(absf(dx)<rr) {
     float hh=sqrtf(rr*rr-dx*dx);
     vstrip(x,maxv(top,iy-hh),minv(bottom,iy+hh),INK);
   }
   rr-=2.7f;
   if(absf(dx)<rr) {
     float hh=sqrtf(rr*rr-dx*dx);
     vstrip(x,maxv(top,iy-hh),minv(bottom,iy+hh),BLUE);
   }
   rr=smoothPupil;
   if(absf(dx)<rr) {
     float hh=sqrtf(rr*rr-dx*dx);
     vstrip(x,maxv(top,iy-hh),minv(bottom,iy+hh),INK);
   }
 }
 // A mildly uneven ink contour, not eyelashes.
 for(int x=17;x<=223;x++) {
   float u=(x-cx)/99.0f;
   if(absf(u)>1.0f) continue;
   float r=1.9f+0.35f*sinf(u*9.0f+1.0f);
   disk(x,topEdge[x],r,INK); disk(x,bottomEdge[x],r,INK);
 }
 // One separate expressive eyebrow, tapered like a brush stroke.
 for(int x=45;x<=195;x++) {
   float u=(x-120.0f)/75.0f;
   float by=81.0f-18.0f*(1.0f-u*u)-smoothBrow+smoothTilt*u;
   by+=wobble(u,7.0f);
   float r=1.1f+2.1f*(1.0f-u*u)+0.25f*sinf(u*11.0f);
   disk(x+shakeX*0.5f,by+shakeY*0.5f,r,INK);
 }
}
