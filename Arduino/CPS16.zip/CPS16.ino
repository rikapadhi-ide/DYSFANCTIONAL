#include <ESP32Servo.h>
#include "EyeDisplay.h"

Servo s1; // Base: pin 6
Servo s2; // Arm: pin 5
Servo s3; // Neck: pin 7

char currentClass = '0';

// Keep the eye animated during motion delays.
// New commands are read after the current motion finishes.
void eyeDelay(unsigned long durationMs) {
  unsigned long started = millis();

  while (millis() - started < durationMs) {
    eyeUpdate();
    delay(1);
  }
}

void setup() {
  Serial.begin(9600);

  eyeBegin();

  s1.setPeriodHertz(50);
  s2.setPeriodHertz(50);
  s3.setPeriodHertz(50);

  s1.attach(6);
  s2.attach(5);
  s3.attach(7);

  Serial.println("Ready: send 1, 2, 3 or 4.");
}

void loop() {
  eyeUpdate();

  // Read class commands from Processing or Serial Monitor.
  while (Serial.available() > 0) {
    char incoming = Serial.read();

    if (incoming >= '1' && incoming <= '4') {
      if (incoming != currentClass) {
        Serial.print("Received class: ");
        Serial.println(incoming);
      }

      currentClass = incoming;
      eyeSet(incoming - '0');
    }
  }

if (currentClass == '1') {
  for (int pos = 60; pos <= 90; pos += 3) {
    s1.write(pos);
    eyeDelay(200);
  }

  currentClass = '0';
}

  // CLASS 2: Threat.
  else if (currentClass == '2') {
    for (int pos = 90; pos <= 180; pos += 3) {
      s2.write(pos);
      eyeDelay(150);
    }

    for (int pos = 180; pos >= 90; pos -= 3) {
      s2.write(pos);
      eyeDelay(150);
    }

    s1.write(60);
  }

  // CLASS 3: Begging eye animation.
  else if (currentClass == '3') {
    eyeUpdate();
  }

  // CLASS 4: Sleepy.
  else if (currentClass == '4') {
    s1.write(60);
    eyeDelay(500);

    s3.write(80);

    for (int pos = 80; pos <= 150; pos += 3) {
      s3.write(pos);
      eyeDelay(150);
    }

    for (int pos = 150; pos >= 110; pos -= 3) {
      s3.write(pos);
      eyeDelay(150);
    }

    for (int pos = 110; pos <= 150; pos += 3) {
      s3.write(pos);
      eyeDelay(150);
    }
  }
}